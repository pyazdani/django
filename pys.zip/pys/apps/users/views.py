from django.shortcuts import render, redirect
from django.contrib import messages
from models import User, UserManager
import bcrypt

def routetomain(request):
    return redirect('/main')

def index(request):
    return render(request, 'users/index.html')

def login(request):
    errors = User.objects.loginvalidator(request.POST)
    if len(errors):
        for tag,error in errors.iteritems():
            messages.error(request, error, extra_tags=tag)
        return redirect('/')
    else:
        request.session['name'] = User.objects.get(email=request.POST['email']).first_name
        request.session['user_id'] = User.objects.get(email=request.POST['email']).id
        return redirect('/travels')

def register(request):
    errors = User.objects.validator(request.POST)
    if len(errors):
        for tag,error in errors.iteritems():
            messages.error(request, error, extra_tags=tag)
    else:
        pwhash = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt())
        user = User.objects.create(first_name = request.POST['fname'], last_name = request.POST['lname'], email = request.POST['email'], password = pwhash)
        request.session['name'] = request.POST['fname']
        request.session['user_id'] = user.id
        return redirect('/travels')
    return redirect('/')


def logout(request):
    request.session.clear()
    messages.add_message(request, messages.INFO, "You have been logged out.", extra_tags='logout')
    return redirect('/')
